# Stick Hero with Canvas

A Pen created on CodePen.io. Original URL: [https://codepen.io/HunorMarton/pen/xxOMQKg](https://codepen.io/HunorMarton/pen/xxOMQKg).

Bridge-building game heavily inspired by Stick Hero with JavaScript and Canvas.

If you want to know how this game was made, check out this video, that goes through the main ideas: 

[https://youtu.be/eue3UdFvwPo](https://youtu.be/eue3UdFvwPo)

Follow me on [twitter](https://twitter.com/HunorBorbely)

I have no assotiation with the original game, but if you are interested you can find here for [iOS](https://apps.apple.com/us/app/stick-hero/id918338898)
and on [Android](https://play.google.com/store/apps/details?id=com.ketchapp.stickhero&hl=en&gl=US)