/* =Credits
--------------------------

 * Loading 9 by http://demo.gavick.com/wordpress/game/


Some other nice animations :

- https://codepen.io/adonisk/pen/vghsm
- https://codepen.io/adonisk/pen/vghsm
- https://codepen.io/m412c0/pen/Lhzer

*/
