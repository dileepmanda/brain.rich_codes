# CSS3 Loading animations

A Pen created on CodePen.io. Original URL: [https://codepen.io/Manoz/pen/kyWvQw](https://codepen.io/Manoz/pen/kyWvQw).

Some css3 loading animations experiments.
Have fun and remember to share what you learn :)