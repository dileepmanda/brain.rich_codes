# Voyage Slider | GSAP

A Pen created on CodePen.io. Original URL: [https://codepen.io/dev_loop/pen/MWKbJmO](https://codepen.io/dev_loop/pen/MWKbJmO).

Inspired by this design: https://dribbble.com/shots/6759822-Voyage-travel-website