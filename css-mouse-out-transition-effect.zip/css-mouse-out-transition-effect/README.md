# CSS mouse-out transition effect

A Pen created on CodePen.io. Original URL: [https://codepen.io/argyleink/pen/poEjvpd](https://codepen.io/argyleink/pen/poEjvpd).

