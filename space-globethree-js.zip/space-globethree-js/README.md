# Space globe - Three.js

A Pen created on CodePen.io. Original URL: [https://codepen.io/isladjan/pen/bGpjZwN](https://codepen.io/isladjan/pen/bGpjZwN).

Three.js is hard to learn but I am trying

Photo: NASA Images & freepic.com