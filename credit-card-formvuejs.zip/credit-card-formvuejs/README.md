# Credit Card Form - VueJs

A Pen created on CodePen.io. Original URL: [https://codepen.io/JavaScriptJunkie/pen/YzzNGeR](https://codepen.io/JavaScriptJunkie/pen/YzzNGeR).

A fantastic credit card form with smooth and sweet micro-interactions. Includes number formatting, validation and automatic card type detection. Built with vuejs and also fully responsive.

See on Github: https://github.com/muhammederdem/credit-card-form