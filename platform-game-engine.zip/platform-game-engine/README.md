# Platform game engine

A Pen created on CodePen.io. Original URL: [https://codepen.io/dissimulate/pen/AGYEby](https://codepen.io/dissimulate/pen/AGYEby).

A simple platform game engine, the map is customisable and scriptable. Refer to the comments in the "map" variable for instructions.

I plan to expand the engine in the future, the ability to use images for tiles and the player is one thing that I have in mind. Any suggestions are welcome.