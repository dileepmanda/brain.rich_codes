# Computer store landing page

A Pen created on CodePen.io. Original URL: [https://codepen.io/r_e_d_ant/pen/oNWZgpy](https://codepen.io/r_e_d_ant/pen/oNWZgpy).

