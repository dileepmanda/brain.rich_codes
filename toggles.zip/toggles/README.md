# Toggles

A Pen created on CodePen.io. Original URL: [https://codepen.io/oliviale/pen/xxboXzo](https://codepen.io/oliviale/pen/xxboXzo).

Do you want your toggle fancy or functional? Yes.