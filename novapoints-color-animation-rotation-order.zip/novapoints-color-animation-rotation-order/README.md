# Nova - Points (color, animation, rotation.order)

A Pen created on CodePen.io. Original URL: [https://codepen.io/prisoner849/pen/RwyzrVj](https://codepen.io/prisoner849/pen/RwyzrVj).

An attempt to show how to put points in formations, animate and color them. Also, to show how to use rotation.order to incline a rotating object.