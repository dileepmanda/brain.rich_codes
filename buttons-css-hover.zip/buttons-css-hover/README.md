# Buttons. CSS Hover

A Pen created on CodePen.io. Original URL: [https://codepen.io/Marina_Os/pen/OJyWPbL](https://codepen.io/Marina_Os/pen/OJyWPbL).

CSS buttons hover effects