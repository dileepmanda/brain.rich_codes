# Checkbox group styled as tiles

A Pen created on CodePen.io. Original URL: [https://codepen.io/havardob/pen/BapJYMg](https://codepen.io/havardob/pen/BapJYMg).

A demonstration of how to create checkboxes that doesn't necessarily looks like... well, checkboxes. 

Icons by https://phosphoricons.com/ 